	<!-- top Products -->
<?php 
	if(isset($_GET['huydon'])&& isset($_GET['magiaodich'])){
		$huydon = $_GET['huydon'];
		$magiaodich = $_GET['magiaodich'];
	}else{
		$huydon = '';
		$magiaodich = '';
	}
	$sql_update_donhang = mysqli_query($conn,"UPDATE donhang SET huydon='$huydon' WHERE mahang='$magiaodich'");
	$sql_update_giaodich = mysqli_query($conn,"UPDATE giaodich SET huydon='$huydon' WHERE magiaodich='$magiaodich'");
?>
	<div class="ads-grid py-sm-5 py-4">
		<div class="container py-xl-4 py-lg-2">
			<!-- tittle heading -->
			<h3 class="tittle-w3l text-center mb-lg-5 mb-sm-4 mb-3">
				
				<span>Your Order</span>
				
				
				</h3>
			<!-- //tittle heading -->
			<div class="row">
				<!-- product left -->
				<div class="agileinfo-ads-display col-lg-9">
					<div class="wrapper">
						<!-- first section -->
						
							<div class="row">
								<?php
									if(isset($_SESSION['dangnhap_home'])){
										echo $_SESSION['dangnhap_home'].' Order: ';
									}
								?>
							</div>
							<div class="col-md-12">
						        <h4>History</h4>
						        <?php
						        if(isset($_GET['khachhang'])){
						          $id_khach = $_GET['khachhang'];
						        }else{
						          $id_khach = '';
						        }
						        $sql_select_lichsu = mysqli_query($conn,"SELECT * FROM giaodich WHERE khachhang_id='$id_khach' GROUP BY magiaodich"); 
						        ?> 
						        <table class="table table-bordered ">
						          <tr>
						            <th>SL No.</th>
						            <th>ID</th>  
						            <th>Date</th>
						            <th>Manage</th>
						            <th></th>
						            <th>Cancel Order</th>
						          </tr>
						          <?php
						          $i = 0;
						          while($row_lichsu = mysqli_fetch_array($sql_select_lichsu)){ 
						            $i++;
						          ?> 
						          <tr>
						            <td><?php echo $i; ?></td>
						            
						            <td><?php echo $row_lichsu['magiaodich']; ?></td>
						          						            
						            <td><?php echo $row_lichsu['ngaythang'] ?></td>
						          <td><a href="index.php?quanli=donhang&khachhang=<?php echo $_SESSION['khachhang_id']?>&magiaodich=<?php echo $row_lichsu['magiaodich'] ?>">Details</a></td>
						          <td>
						          <?php
						          	if($row_lichsu['tinhtrangdonhang']==0){
						          		echo 'Waiting';
						          	}else{
						          		echo 'Done|Shipping';
						          	}
						          ?>
						          	
						          </td>
						          <td>
						          <?php
									if($row_lichsu['huydon']==0){ 
								  ?>
						          <a href="index.php?quanli=donhang&khachhang=<?php echo $_SESSION['khachhang_id'] ?>&magiaodich=<?php echo $row_lichsu['magiaodich'] ?>&huydon=1">Cancel</a>
									<?php
									}elseif($row_lichsu['huydon']==1){											
									?>
									<p>Waiting...</p>
									<?php
									}else{
										echo 'Cancelled';
									}
									?>
						          </td>
						          </tr>
						           <?php
						          } 
						          ?> 
						        </table>
						      </div>

						      <div class="col-md-12">
					        <p>DETAILS</p>
					        <?php
					        if(isset($_GET['magiaodich'])){
					          $magiaodich = $_GET['magiaodich'];
					        }else{
					          $magiaodich = '';
					        }
					        $sql_select_lichsu = mysqli_query($conn,"SELECT * FROM giaodich,khachhang,sanpham WHERE giaodich.sanpham_id=sanpham.sanpham_id AND khachhang.khachhang_id=giaodich.khachhang_id AND giaodich.magiaodich='$magiaodich' ORDER BY giaodich.giaodich_id DESC"); 
					        ?> 
					        <table class="table table-bordered ">
					          <tr>
					            <th>SL No.</th>
					            <th>ID</th>
					            <th>Product</th>
					            <th>Quantity</th>
					            <th>Date</th>
					            
					          </tr>
					          <?php
					          $i = 0;
					          while($row_lichsu = mysqli_fetch_array($sql_select_lichsu)){ 
					            $i++;
					          ?> 
					          <tr>
					            <td><?php echo $i; ?></td>
					            
					            <td><?php echo $row_lichsu['magiaodich']; ?></td>
					          
					            <td><?php echo $row_lichsu['sanpham_name']; ?></td>

					            <td><?php echo $row_lichsu['soluong']; ?></td>
					            
					            <td><?php echo $row_lichsu['ngaythang'] ?></td>

					          	
					          
					          </tr>
					           <?php
					          } 
					          ?> 
					        </table>
					      </div>    
						
						<!-- //first section -->
					
					</div>
				</div>
		
	
						<!-- //fourth section -->
				
			
				<!-- //product left -->
				<!-- product right -->

			</div>
		</div>
	</div>
	<!-- //top products --